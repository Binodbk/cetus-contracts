// EXCERPT — this checkout (VERSION = 15), packages/cetus_clmm/sources/config.move
// ACL_EMERGENCY_UNPAUSE = 5 (legacy bit kept), ACL_EMERGENCY_PAUSE = 6, new upper bound.

44:/// - ACL_CLAIM_PROTOCOL_FEE (2): Can claim protocol fees
45:/// - ACL_PARTNER_MANAGER (3): Can add/remove partners and update partner fee rates
46:/// - ACL_REWARDER_MANAGER (4): Can add/remove rewarders and update rewarder rates
47:/// - ACL_EMERGENCY_UNPAUSE (5): Can restore the protocol after an emergency pause
48:/// - ACL_EMERGENCY_PAUSE (6): Can trigger emergency pause functionality
49:const ACL_POOL_MANAGER: u8 = 0;
50:const ACL_FEE_TIER_MANAGER: u8 = 1;
51:const ACL_CLAIM_PROTOCOL_FEE: u8 = 2;
52:const ACL_PARTNER_MANAGER: u8 = 3;
53:const ACL_REWARDER_MANAGER: u8 = 4;
54:// Keep the legacy role at bit 5 so existing multisig unpause permissions remain valid.
55:const ACL_EMERGENCY_UNPAUSE: u8 = 5;
56:const ACL_EMERGENCY_PAUSE: u8 = 6;
57:
58:/// The version of this package, need increase it when upgrade the package.
59:const VERSION: u64 = 15;
60:/// The version of the package that requires an emergency restore
61:const EMERGENCY_RESTORE_NEED_VERSION: u64 = 18446744073709551000;
62:/// The version of the package that requires an emergency pause
63:const EMERGENCY_PAUSE_VERSION: u64 = 9223372036854775808;
64:
65:const EMERGENCY_PAUSE_BEFORE_VERSION: vector<u8> = b"emergency_pause_before";
66:
468:}
469:
470:/// Check member has emergency pause role.
471:/// * `config` - The global config
472:/// * `member` - The member address
473:public fun check_emergency_pause_role(config: &GlobalConfig, member: address) {
474:    assert!(acl::has_role(&config.acl, member, ACL_EMERGENCY_PAUSE), ENoEmergencyPausePermission)
475:}
476:
477:/// Check member has emergency unpause role.
478:/// * `config` - The global config
479:/// * `member` - The member address
480:public fun check_emergency_unpause_role(config: &GlobalConfig, member: address) {
481:    assert!(
482:        acl::has_role(&config.acl, member, ACL_EMERGENCY_UNPAUSE),
483:        ENoEmergencyUnpausePermission,
484:    )
485:}
486:
518:public fun acl(config: &GlobalConfig): &acl::ACL {
519:    &config.acl
520:}
521:
522:/// Check current packages is valid.
523:/// * `config` - The global config
524:public fun checked_package_version(config: &GlobalConfig) {
525:    assert!(VERSION >= config.package_version, EPackageVersionDeprecate);
526:}
527:
528:/// Check package version satisfy EMERGENCY_RESTORE_NEED_VERSION.
529:/// * `config` - The global config
530:public fun check_emergency_restore_version(config: &GlobalConfig) {
531:    assert!(
532:        config.package_version == EMERGENCY_RESTORE_NEED_VERSION,
533:        EConfigVersionNotEqualEmergencyRestoreVersion,
534:    );
535:}
536:
537:/// Emergency pause the protocol.
538:/// * `config` - The global config
539:/// * `ctx` - The transaction context
540:public fun emergency_pause(config: &mut GlobalConfig, ctx: &TxContext) {
541:    check_emergency_pause_role(config, tx_context::sender(ctx));
542:    let old_version = config.package_version;
543:    config.package_version = EMERGENCY_PAUSE_VERSION;
544:    assert!(
545:        !dynamic_field::exists_with_type<vector<u8>, u64>(
546:            &config.id,
547:            EMERGENCY_PAUSE_BEFORE_VERSION,
548:        ),
549:        EProtocolAlreadyEmergencyPause,
550:    );
551:    dynamic_field::add(&mut config.id, EMERGENCY_PAUSE_BEFORE_VERSION, old_version);
552:}
553:
554:public fun emergency_unpause(config: &mut GlobalConfig, version: u64, ctx: &TxContext) {
555:    check_emergency_unpause_role(config, tx_context::sender(ctx));
556:    assert!(
557:        dynamic_field::exists_with_type<vector<u8>, u64>(
558:            &config.id,
559:            EMERGENCY_PAUSE_BEFORE_VERSION,
560:        ),
561:        EProtocolNotEmergencyPause,
562:    );
563:    let before_version = dynamic_field::remove<vector<u8>, u64>(
564:        &mut config.id,
565:        EMERGENCY_PAUSE_BEFORE_VERSION,
566:    );
567:    assert!(version >= before_version && version <= package_version(), EInvalidPackageVersion);
568:    config.package_version = version;
569:}
570:
571:/// Update the package version.
572:/// * `admin_cap` - The admin cap
573:/// * `config` - The global config
574:/// * `version` - The new package version
575:public fun update_package_version(_: &AdminCap, config: &mut GlobalConfig, version: u64) {
576:    let old_version = config.package_version;
577:    assert!(version > old_version && version < EMERGENCY_PAUSE_VERSION, EInvalidPackageVersion);
578:    config.package_version = version;
579:    emit(SetPackageVersion {
580:        new_version: version,
581:        old_version,
582:    })
583:}
584:
585:/// Get the package version.
586:/// * Returns the package version
587:public fun package_version(): u64 {
588:    VERSION
589:}
590:
591:// === Functions only for test ===
592:#[test_only]
593:public fun new_global_config_for_test(
594:    ctx: &mut TxContext,
595:    protocol_fee_rate: u64,
596:): (AdminCap, GlobalConfig) {
597:    let (mut global_config, admin_cap) = (
598:        GlobalConfig {
599:            id: object::new(ctx),
600:            protocol_fee_rate,
