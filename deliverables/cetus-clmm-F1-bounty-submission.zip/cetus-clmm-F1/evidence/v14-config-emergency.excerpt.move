// EXCERPT — upstream branch 'version-14' (VERSION = 14), packages/cetus_clmm/sources/config.move
// ACL_EMERGENCY_PAUSE = 5; no upper bound on the version argument.

44:/// - ACL_PARTNER_MANAGER (3): Can add/remove partners and update partner fee rates
45:/// - ACL_REWARDER_MANAGER (4): Can add/remove rewarders and update rewarder rates
46:/// - ACL_EMERGENCY_PAUSE (5): Can trigger emergency pause functionality
47:const ACL_POOL_MANAGER: u8 = 0;
48:const ACL_FEE_TIER_MANAGER: u8 = 1;
49:const ACL_CLAIM_PROTOCOL_FEE: u8 = 2;
50:const ACL_PARTNER_MANAGER: u8 = 3;
51:const ACL_REWARDER_MANAGER: u8 = 4;
52:const ACL_EMERGENCY_PAUSE: u8 = 5;
53:
54:/// The version of this package, need increase it when upgrade the package.
55:const VERSION: u64 = 14;
56:/// The version of the package that requires an emergency restore
57:const EMERGENCY_RESTORE_NEED_VERSION: u64 = 18446744073709551000;
58:/// The version of the package that requires an emergency pause
59:const EMERGENCY_PAUSE_VERSION: u64 = 9223372036854775808;
60:
460:/// * `member` - The member address
461:public fun check_rewarder_manager_role(config: &GlobalConfig, member: address) {
462:    assert!(acl::has_role(&config.acl, member, ACL_REWARDER_MANAGER), ENoRewarderManagerPermission)
463:}
464:
465:/// Check member has emergency pause role.
466:/// * `config` - The global config
467:/// * `member` - The member address
468:public fun check_emergency_pause_role(config: &GlobalConfig, member: address) {
469:    assert!(acl::has_role(&config.acl, member, ACL_EMERGENCY_PAUSE), ENoEmergencyPausePermission)
470:}
471:
472:/// Get tick_spacing of FeeTier.
473:/// * `fee_tier` - The fee tier
474:/// * Returns the tick spacing
475:public fun tick_spacing(fee_tier: &FeeTier): u32 {
520:}
521:
522:/// Emergency pause the protocol.
523:/// * `config` - The global config
524:/// * `ctx` - The transaction context
525:public fun emergency_pause(config: &mut GlobalConfig, ctx: &TxContext) {
526:    check_emergency_pause_role(config, tx_context::sender(ctx));
527:    let old_version = config.package_version;
528:    config.package_version = EMERGENCY_PAUSE_VERSION;
529:    assert!(
530:        !dynamic_field::exists_with_type<vector<u8>, u64>(
531:            &config.id,
532:            EMERGENCY_PAUSE_BEFORE_VERSION,
533:        ),
534:        EProtocolAlreadyEmergencyPause,
535:    );
536:    dynamic_field::add(&mut config.id, EMERGENCY_PAUSE_BEFORE_VERSION, old_version);
537:}
538:
539:public fun emergency_unpause(config: &mut GlobalConfig, version: u64, ctx: &TxContext) {
540:    check_emergency_pause_role(config, tx_context::sender(ctx));
541:    assert!(
542:        dynamic_field::exists_with_type<vector<u8>, u64>(
543:            &config.id,
544:            EMERGENCY_PAUSE_BEFORE_VERSION,
545:        ),
546:        EProtocolNotEmergencyPause,
547:    );
548:    let before_version = dynamic_field::remove<vector<u8>, u64>(
549:        &mut config.id,
550:        EMERGENCY_PAUSE_BEFORE_VERSION,
551:    );
552:    assert!(version >= before_version, EInvalidPackageVersion);
553:    config.package_version = version;
554:}
555:
556:/// Update the package version.
557:/// * `admin_cap` - The admin cap
558:/// * `config` - The global config
559:/// * `version` - The new package version
560:public fun update_package_version(_: &AdminCap, config: &mut GlobalConfig, version: u64) {
